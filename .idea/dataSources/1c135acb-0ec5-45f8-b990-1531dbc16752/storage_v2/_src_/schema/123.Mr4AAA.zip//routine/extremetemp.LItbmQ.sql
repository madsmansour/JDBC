create procedure ExtremeTemp(IN number_of_results int, IN Sort tinyint(1))
  BEGIN 
SELECT temp,time FROM zbc_fetch_data
GROUP BY
CASE WHEN Sort = 0 
              THEN temp END ASC,
CASE WHEN Sort = 1
              THEN temp END DESC
LIMIT number_of_results;
END;

